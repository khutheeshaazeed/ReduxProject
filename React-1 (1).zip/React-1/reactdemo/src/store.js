import { createStore } from 'redux';
import counterReducer from './counterReducer'; // Assuming your reducer is correctly defined in `counterReducer.js`

const store = createStore(counterReducer);

export default store;
