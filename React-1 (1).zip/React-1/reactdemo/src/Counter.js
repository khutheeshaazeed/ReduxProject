import React from 'react';
import { useSelector } from 'react-redux';

const Counter = () => {
  const count = useSelector(state => state.count);
  let countColor = 'black';

  if (count > 0) {
    countColor = 'green'; 
  } else if (count < 0) {
    countColor = 'red'; 
  }

  return (
    <div>
      <h2 style={{ color: countColor }}>Counter: {count}</h2>
    </div>
  );
};

export default Counter;
