import React from 'react';
import Counter from './Counter';
import CounterControls from './CounterControls';

function App() {
  return (
    <div>
     <center>
     <Counter />
      <CounterControls />
     </center>
    </div>
  );
}

export default App;
